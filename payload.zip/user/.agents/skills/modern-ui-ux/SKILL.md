---
name: modern-ui-ux
description: "Design, implement, audit, or refine UI/UX for web apps and PWAs, and visual communication for social graphics, PDFs, documents, and PowerPoint presentations. Use when visual hierarchy, interaction, accessibility, or visual storytelling is central. Exclude programming, infrastructure, data processing, and text-only work without a design objective."
---

# Modern UI UX

Produce purposeful, research-informed design for the audience's task and the user's chosen medium. "Modern" means clear, usable, appropriate, and well executed; it does not prescribe a visual trend. Preserve explicit user choices, approved copy/assets, brand identity, and functioning project conventions.

## Choose the mode

- **CREATE:** Design and implement the requested deliverable.
- **AUDIT:** Inspect the supplied or rendered design and report prioritized, evidence-backed issues; do not edit files or the live product.
- **REFINE:** Improve the selected existing design. Preserve its identity and working behavior; avoid a broader redesign unless requested.
- **RESEARCH:** Study standards, primary research, and user-provided inspiration. Explain applicability and uncertainty; do not implement unless requested.

Infer the mode from the request. Mixed tasks can combine modes within the authorized scope.

## Load only what the task needs

Select by active deliverable, not every format mentioned in background context. Read foundations when establishing direction or diagnosing composition; skip it for a narrow fix with an established system. Read QA for the active medium and relevant checks only. Never load all references by default.

| Task | Reference |
| --- | --- |
| Audience, hierarchy, typography, grids, composition, brand, information architecture | [design-foundations.md](references/design-foundations.md) |
| Web/PWA screens, flows, responsive implementation, accessibility, app states | [web-pwa.md](references/web-pwa.md) |
| Posters, carousels, thumbnails, banners, infographics, educational graphics | [social-content.md](references/social-content.md) |
| Reports, booklets, handouts, brochures, screen or print PDF | [pdf-documents.md](references/pdf-documents.md) |
| PowerPoint narratives, editable decks, speaker-led or self-reading | [presentations.md](references/presentations.md) |
| Rendered review, accessibility, functional and export verification | [quality-assurance.md](references/quality-assurance.md) |

For a deck exported to PDF, use presentations plus QA; add PDF guidance only for document accessibility or print requirements. This skill supplies design decisions, not a new rendering engine. Use the environment's applicable authoring skill/tool for the requested format when available. If unavailable, use existing project tools and disclose unsupported checks. Do not install tooling or switch products merely because this skill was selected.

## Work from evidence to the artifact

1. Establish task, audience, medium/placement, constraints, and observable success criteria from available context. Ask only for missing information that materially blocks the work; state reasonable assumptions otherwise.
2. Inspect relevant source content, current implementation, brand assets, and reference designs. Before editing code, inspect Git status and preserve unrelated changes. For audits/refinements, capture the rendered baseline when accessible.
3. Select relevant references. Develop a specific direction tied to the task: reading order, focal point, density, typography, composition, and relevant states. Follow existing approval stages without inventing new ones.
4. Create within existing tools and conventions. Reuse working components and approved assets. Match a supplied reference faithfully when requested; do not fabricate brand assets or licenses.
5. Visually inspect actual output under intended viewing conditions. Run relevant accessibility, functional, consistency, and export checks; correct confirmed defects within scope. An unavailable renderer is a limitation, not a passing check.
6. Report deliverables or prioritized findings, evidence, actual checks, untested assumptions, and remaining limits. Separate observed defects from hypotheses and preferences.

## Evidence and boundaries

Distinguish **standards** (testable criteria with applicability and exceptions), **platform requirements** (version/placement dependent), **research-backed heuristics** (contextual guidance), and **art direction** (reasoned aesthetic choice). A heuristic or preference is not a conformance rule.

Prefer primary specifications, peer-reviewed research, documented usability research, and authoritative software documentation. References contain source notes and verification triggers. Recheck changing platform specs, browser/software behavior, and versioned interfaces when relevant; stable principles do not require a new literature review for every edit. Disclose inaccessible sources and unverified claims. Cite source-specific claims near the claim; never invent citations or imply inaccessible full text was read.

Design scope does not authorize changes to authentication, authorization, APIs, storage, backend behavior, privacy protections, or caching policy. Show unsupported states honestly; propose contract changes separately. Do not cache sensitive information for offline convenience. Creating a design does not authorize publishing, deploying, sharing, or sending it externally.

Avoid generic AI aesthetics: decorative gradients, repeated cards, arbitrary empty space, and identical layouts need a task-specific purpose. Do not replace those habits with another compulsory template, palette, type scale, or fixed word/slide count.
