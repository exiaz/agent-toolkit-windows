# PDFs and documents

Use for reports, booklets, handouts, brochures, and long-form layouts. Establish output intent before choosing production settings.

| Intent | Main considerations |
| --- | --- |
| Accessible screen-first | Selectable/searchable text, semantic structure, navigation, useful links, reading order, figure alternatives, magnification. |
| Print production | Trim, binding/folding, margins, bleed, effective image resolution, fonts, printer-supplied color/output specification. |
| Visual presentation PDF | Fixed slide/page composition and display legibility. Appearance alone proves neither accessibility nor editability. |

One file may not serve all purposes equally. Make variants only when requested or necessary and describe their roles. If editability is requested, retain an appropriate source; a flattened PDF is not an editable document substitute.

## Sustained reading and navigation

Choose page size/grid for content and viewing/binding context. Establish typography roles, line measure/spacing, paragraph rhythm, and heading hierarchy. Prefer styles/layout rules to fragile manual spacing. Inspect running heads, folios, captions, section openings, widows/orphans, and accidental blank pages.

Keep claims, evidence, charts, and qualifications close. For booklets, account for spreads, inner margins, folding, and page order; do not impose signatures or reorder reader pages unless requested by the print provider. Handouts and brochures should support scanning and their intended practical use.

Tables need legible labels, units, clear relationships, and repeated headers across pages when supported. Avoid critical row/caption splits and unreadable whole-table shrinking. Preserve values and source notes. Simplify the presentation of evidence without changing its meaning.

## Accessibility structure

Use semantic headings, lists/tables, logical reading order, meaningful links, title/language metadata, figure alternatives, and appropriate bookmarks. Mark decorative content as artifacts where supported. Prefer real text to outlines or pixels; OCR alone does not establish semantics.

Inspect exported tags, reading/tab order, links, table relationships, and alternatives when tools permit: export can lose source structure. Test navigation and relevant assistive technology. If the generator cannot produce a correctly tagged PDF, disclose it and retain a more accessible source/alternative within scope.

WCAG defines accessibility outcomes; W3C PDF Techniques are informative implementation examples. PDF/UA is a separate technical conformance standard. Identify the requested edition, PDF version, validator/profile, and human review coverage before claiming conformance. Tags, a checker pass, or a clean visual render alone do not prove full WCAG or PDF/UA conformance.

## Print preflight

Confirm dimensions, orientation, trim/bleed boxes, safe margins, binding allowances, and marks against the provider's job specification. Extend edge artwork through bleed and keep essential content within the safe area. Do not assume universal bleed, 300 ppi, CMYK conversion, or color-profile requirements. Calculate effective image resolution at placed size and assess against the job's needs.

Check missing/substituted fonts, embedding rights, broken links, transparency/overprint where relevant, and requested output settings. Inspect an actual-size proof and folding/trimming where applicable. Without provider requirements or physical proof, describe the file against its stated assumptions rather than declaring unconditional print readiness.

## Sources

Reviewed 2026-10-27. Recheck exporter/checker versions and job-specific printer requirements.

- [W3C: WCAG 2.2 PDF Techniques](https://www.w3.org/WAI/WCAG22/Techniques/#pdf) — living informative guidance, including PDF1/2/3/6/9/11/16/18/21. Replaces the unmaintained [older collection](https://www.w3.org/TR/WCAG-TECHS/pdf.html); evaluate against applicable normative criteria.
- [PDF Association: PDF/UA-2](https://pdfa.org/iso-14289-2-pdfua-2) and [ISO 14289-2:2024](https://www.iso.org/standard/82278.html) — edition 1, 2024-03; PDF/UA-2 addresses PDF 2.0. Overview/catalog information is not the full normative specification. Verify edition and validation profile before conformance work.
- [WCAG 2.2](https://www.w3.org/TR/WCAG22/) — Recommendation 2024-12-12. Distinguish accessibility outcomes from format conformance and print preflight.
- [Adobe: Booklet printing settings](https://helpx.adobe.com/indesign/desktop/print/print-booklets/booklet-printing-settings.html) — living, application-specific guidance. Verify actual software version and print provider instructions before imposition.
