# Quality assurance

Apply shared checks plus the active medium only. Scale effort to the requested change/risk. AUDIT gathers evidence without editing; CREATE/REFINE can repair confirmed in-scope defects.

## Shared evidence

Inspect the actual rendered artifact, not only source, extracted text, coordinates, or tool claims. Check intended viewing size and close-up. Compare approved content/brand assets. Verify hierarchy, composition, alignment, spacing, contrast, legibility, imagery, and repeated roles. Confirm numbers, dates, units, sources, sequence, filenames, and output dimensions.

Record artifact/version, page/slide/viewport, state, environment, method, result, and limits. Keep measurements reproducible. Unavailable rendering means missing coverage; never invent screenshots or pass visual QA from source alone.

Findings need location, observed problem, task/audience consequence, evidence, and a scoped fix. Prioritize blocked tasks, misleading/data-loss behavior, and accessibility barriers above polish. Label hypotheses needing runtime/user tests and separate art preferences from defects. Do not invent findings to fill a quota.

## Web/PWA

- Exercise relevant primary/recovery journeys using permitted test data. Inspect supported loading, empty, validation, pending, error, denied, and success states. Do not mutate production for screenshots.
- Inspect narrow/mobile, intermediate, and wide layouts chosen from content/supported devices, plus orientation and virtual keyboard as relevant. Follow an existing project matrix. Emulation does not prove real-device or installed-PWA compatibility.
- Test keyboard access, focus/order, dialogs, labels, semantics, and status/error feedback. Include representative screen-reader coverage where available; automation alone cannot establish conformance.
- Measure actual text/background contrast: 4.5:1 ordinary text; 3:1 large text (at least 18 pt regular or 14 pt bold). Apply incidental/logotype exceptions narrowly; ordinary branded text is not exempt. For imagery/gradients, assess the worst relevant background.
- Required control/state cues and meaningful graphics need 3:1 against adjacent colors under 1.4.11 with its documented exceptions. Do not communicate meaning through color alone.
- Pointer targets: 2.5.8 AA requires 24 by 24 CSS px or a valid exception. Check hit areas, not just icons. Undersized-target spacing uses 24 CSS px diameter circles centered on bounding boxes, not a universal gap. Inline, equivalent-control, user-agent, and essential exceptions have conditions. Larger targets can help; 44 px is not the AA minimum.
- Check text resizing to 200%, text-spacing overrides, and reflow at 320 CSS px equivalent width for vertical content (256 CSS px height for horizontal content). Essential two-dimensional content can be excepted; surrounding content must still work. Do not exempt a whole dashboard because it contains a table.
- For PWA work, inspect relevant install/standalone behavior, offline/reconnect failure, pending sync, updates, and safe cache behavior. State untested browser/OS coverage.
- Record measured LCP/INP/CLS and field/lab provenance using the web/PWA reference. Do not infer performance from appearance. Run relevant repository checks and inspect the final diff.

This focused aid is not an exhaustive WCAG 2.2 A/AA checklist or certification procedure.

## Social graphics

Verify current requirements for the exact placement. Inspect every panel/export at phone and thumbnail scale: crop/overlay safe areas, sequence, compression, glyphs, logo provenance, rights/credit, and equivalent caption/alt content. Inaccessible official guidance leaves specs unverified; local dimensions alone do not prove acceptance.

## PDFs/documents

Render all pages; inspect contact sheet plus readable views. Check pagination, clipping, table splits, running heads, blanks, fonts, imagery, dimensions, and margins. Verify searchable text, links/bookmarks, tags/reading order where supported. Check job-specific trim, bleed, fonts, effective image resolution, and color for print. For conformance claims, record standard/profile and automated/human checks; appearance is insufficient.

## Presentations

Render all slides and inspect sequence plus individual previews: overflow, readability, alignment, consistency, and source preservation. Check native editability, titles, alt text, reading order, links, charts, and media where tools permit. Reopen exports if conversion may change them. Distinguish render, editability, application compatibility, and accessibility results.

## Close the loop

Repair confirmed scoped defects and rerun checks affected by repairs. Stop when the deliverable and required checks are complete; avoid unrelated redesign or repeated broad testing. Handoff changes/findings, files, actual checks/results, and remaining limits. Use "not tested", "not applicable" with reason, and "blocked" accurately rather than a blanket pass.

## Sources

Reviewed 2026-10-27. Recheck normative criteria/errata for conformance and software instructions for installed versions.

- [W3C: Easy Checks](https://www.w3.org/WAI/test-evaluate/preliminary/) — living preliminary guide, explicitly not comprehensive. Use current evaluation guidance for formal audit planning.
- [WCAG 2.2](https://www.w3.org/TR/WCAG22/) — Recommendation 2024-12-12; normative criteria including 1.4.4 Resize Text and 1.4.12 Text Spacing.
- W3C informative explanations: [Contrast Minimum](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html), [Non-text Contrast](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html), [Target Size Minimum](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html), [Reflow](https://www.w3.org/WAI/WCAG22/Understanding/reflow.html). Living guidance; check actual exceptions instead of blanket exclusions.
- [W3C: PDF Techniques](https://www.w3.org/WAI/WCAG22/Techniques/#pdf) and [Microsoft: PowerPoint accessibility](https://support.microsoft.com/en-us/accessibility/powerpoint/make-your-powerpoint-presentations-accessible-to-people-with-disabilities) — living technical guidance. Use the format references for conformance and application/version limits.
