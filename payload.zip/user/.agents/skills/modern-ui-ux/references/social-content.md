# Social and content design

Use for posters, Instagram carousels, thumbnails, banners, editorial layouts, infographics, and educational artwork.

## Brief and publication contract

Establish goal, audience, approved copy, brand, action, and exact placement. Separate organic feed posts/carousels, advertisements, stories, and reels/covers. Their crops, overlays, ratios, duration, and export constraints may differ. A user-requested canvas is a design constraint; it is not proof of platform acceptance.

Before final export, verify official requirements for that placement: pixel dimensions/ratio, file type, size limit, sequence/video limits where relevant, crop behavior, and safe areas. Record the source and verification date for material specifications. If official guidance is inaccessible, use the user's confirmed specification or label the export provisional and disclose unverified requirements. Do not substitute advertising specs for organic formats or silently reuse an old size chart.

## Composition and sequence

Choose composition from the content: a photograph with a focal subject, typographic poster, diagram, editorial spread, or comparison can serve different goals. Establish hierarchy before effects. Keep the action, date/location, conditions, and attribution readable when they matter. Safe areas must account for crops and actual interface overlays; there is no universal percentage for every placement.

For carousels, plan a progression from context through explanation/evidence to an appropriate next action. Each panel needs a contribution and enough context to remain understandable when shared alone. Vary rhythm through scale, images, diagrams, and composition while preserving type roles and brand. Do not stretch a simple message into unnecessary panels or repeat identical cards automatically.

For education, match vocabulary, examples, and visual complexity to prior knowledge and reading ability. Pair explanations with relevant diagrams and expose the learning sequence. These choices do not prove improved learning without audience testing. Infographics need units, denominators, periods, source context, and honest encoding; decorative area/volume must not distort quantities. Thumbnails should communicate at small viewing size without misleading the audience.

## Images, copy, and exports

Inspect approved images/logos first. Verify provenance, permitted use, credit, and brand version. Search visibility or downloading does not establish a license. Never invent documentary photographs of real events, factual claims, logos, references, rights, or permissions. Keep generated images within the brief and distinguish illustration from documentary evidence.

Crop with intent and preserve meaningful subjects/context. Apply photography treatments without changing documentary meaning. Test text contrast across the full photo background. Keep text, logos, and diagrams editable when supported by the requested format; image generation is suitable for artwork, not reliable exact factual typesetting.

Inspect every compressed export at phone and thumbnail/crop size. Check sharpness, spelling, glyphs, logo clearance, sequence, and filenames. Where supported, provide useful alt text or equivalent caption content; text embedded in a graphic is not automatically accessible. Publishing needs separate authorization.

## Sources

Reviewed 2026-10-27. Composition guidance is synthesis; platform sizes are deliberately not hardcoded.

- [Instagram Help: image resolution](https://help.instagram.com/1631821640426723) — living platform source; returned HTTP 429 during review. Recheck the exact organic format before export; no current numeric spec is asserted here without verification.
- [Meta Ads Guide](https://www.facebook.com/business/ads-guide) — living advertising requirements by placement. Review redirected to login; verify accessible official guidance before claiming compliance. This is not an organic-format specification.
- [W3C WAI: Images Tutorial](https://www.w3.org/WAI/tutorials/images/) — living guidance. Choose alternatives by image purpose; verify the platform's actual alt-text support.
- [Mayer: Using multimedia for e-learning](https://onlinelibrary.wiley.com/doi/10.1111/jcal.12197) — peer-reviewed review, 2017-06-13. Contextual support for instructional coherence, signaling, and integration; not a guarantee of learning or engagement.
