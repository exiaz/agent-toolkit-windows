# Web apps and PWAs

Use for interaction design, interface audits, and frontend refinement. Preserve authentication, authorization, API contracts, storage, backend behavior, privacy, and caching boundaries unless explicitly in scope.

## Flows, responsive structure, and systems

Map entry, action, result, and recovery using existing routes/components. Provide a recognizable location and way back; preserve deep links/state where supported. Distinguish denied permission, expired session, no data, and service failure. A disabled control or hidden menu is not an authorization boundary.

Start with constrained screens and touch, then use extra space purposefully. Prefer fluid layouts and choose breakpoints where content/interaction fails. Adaptive navigation and density may change presentation without removing essential tasks. Check safe areas, orientation, virtual keyboard, long labels, text zoom, keyboard and pointer use. Avoid hover-only or gesture-only actions.

Dashboards should expose the decision, period, freshness, definitions, and drill-down path. Tables need headers, units, comparisons, sorting/filter state, and relevant totals. Use accessible scrolling or a purposeful alternate view as needed; converting every table to cards can lose comparisons.

Forms need persistent labels, suitable input types/autocomplete, clear required fields, and helpful examples. Identify errors near fields and use a linked summary for long forms when useful. Preserve permitted input after failure. Communicate destructive consequences and use supported confirmation/undo patterns proportionally. Client validation helps users; it does not replace server validation. Request device permissions in context and support refusal honestly.

Reuse tokens and accessible components. Define missing tokens by semantic role, including status/focus/interaction states; do not introduce a new component system for a small fix. Motion should explain cause/state, respect reduced motion, and avoid blocking tasks.

## PWA state model

Inspect actual support before promising resilience.

| State | Design implication |
| --- | --- |
| Browser vs installed | Test standalone navigation, safe areas, launch/deep links, and back behavior without assuming browser chrome. Verify installation on the target platform. |
| Loading / empty / stale | Distinguish progress, no records, and last-known data; expose freshness when relevant. |
| Offline / reconnecting | Network status is a hint, not proof of server reachability. Explain unavailable actions and supported recovery. |
| Sending / pending sync | Distinguish local pending work from confirmed success. Show queue/cancel/retry only when implemented. |
| Failed / unknown result | Preserve permitted input. Reuse existing request identity/idempotency; do not blindly repeat a possibly completed mutation. |
| Update available | Avoid discarding unsaved work or force-refreshing an active task. Respect the service-worker lifecycle. |
| Unsupported capability | Feature-detect and offer a supported fallback; do not require installation or one browser without a real requirement. |

Use existing safe caching rules. Do not cache credentials, private responses, or sensitive data for a convincing offline demo. Offline writes, new persistence, conflict resolution, and changed invalidation require separate architectural scope.

## Accessibility and performance

Target applicable WCAG 2.2 A/AA criteria: semantics, keyboard access, visible focus, meaningful labels, recovery, status announcements, and predictable dialog focus/restoration. Focus must not be entirely hidden by author content (2.4.11 AA); full non-obscuration and Focus Appearance are separate AAA criteria. Include non-drag alternatives, avoid redundant re-entry where applicable, and inspect accessible authentication without changing security rules. Document criterion-specific exceptions; branding and deadlines are not exemptions. See QA for numeric checks.

Measure Core Web Vitals: current good thresholds are LCP <= 2.5 s, INP <= 200 ms, CLS <= 0.1, assessed at the 75th percentile of field visits. Record device class, source, period, and conditions. Lab traces diagnose issues; a single run or Lighthouse score does not establish field performance, and TBT is not a measured INP result. Fix observed causes within scope and remeasure. Disclose absent field data.

## Sources

Reviewed 2026-10-27. Reverify platform/API support and interfaces against target browser/software versions.

- [WCAG 2.2](https://www.w3.org/TR/WCAG22/) — Recommendation 2024-12-12. Normative criteria/exceptions; recheck edition and errata for conformance work. The guidance here is not exhaustive.
- [NN/G: 10 Usability Heuristics](https://www.nngroup.com/articles/ten-usability-heuristics/) — 1994-04-24; reviewed 2024-01-30. Broad heuristics, not certification criteria.
- [Google: Learn PWA](https://web.dev/learn/pwa) and [MDN: PWA best practices](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Best_practices) — living docs; recheck installability, lifecycle, offline capabilities, and browser compatibility when used.
- [Google: Core Web Vitals](https://developers.google.com/search/docs/appearance/core-web-vitals) and [threshold methodology](https://web.dev/articles/defining-core-web-vitals-thresholds) — living docs; methodology updated 2025-05-07. Recheck thresholds and distinguish field/lab evidence.
