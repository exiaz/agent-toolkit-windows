# Presentations

Use for PowerPoint and slide narratives. Determine speaker-led versus self-reading (or both), audience knowledge, venue/device, available time, source material, and editability.

## Narrative and composition

Build a sequence that makes the question, explanation/evidence, implications, and intended response understandable. Preserve supplied narrative and approved copy unless editing is requested. Let complexity and pacing determine word/slide counts; fixed formulas do not establish quality.

Speaker-led slides can foreground arguments or visuals while notes support delivery. Self-reading decks need explicit context, definitions, and transitions. If both are needed, use notes or appropriate supporting detail rather than expecting sparse projected slides to work unassisted.

Choose editorial compositions matched to each idea: annotated image, process, comparison, chart, quotation, or typographic statement. Keep coherent type roles, alignment anchors, margins, color semantics, and photography treatments. Vary composition with the story while keeping readers oriented. Avoid a generic title-and-identical-cards layout repeated for unrelated content.

## Multimedia learning in context

These principles originate in instructional multimedia research; they guide decisions but do not guarantee outcomes for every audience/deck.

- **Coherence:** Remove distractions from the learning goal; retain essential caveats/context.
- **Signaling:** Use headings, emphasis, annotations, or sequence to expose relationships and organization.
- **Segmenting:** Explain complexity in manageable stages with useful pacing or learner control where possible.
- **Spatial contiguity:** Put explanations beside the relevant graphic instead of requiring searches across distant regions.
- **Appropriate redundancy:** Avoid needless dense prose duplicated by narration. Retain captions, necessary labels, unfamiliar terms, language support, accessibility alternatives, and self-reading context.

Account for audience knowledge and viewing conditions. Do not prohibit repeated text or remove captions in the name of a principle. Before quantified learning claims, inspect study participants, task, measures, and limitations; do not reuse a general effect size as a promise.

## Data and editable PowerPoint

Preserve values, denominators, dates, baselines, units, uncertainty, and source context. Match chart type to comparison and use useful direct labels. Avoid distorted axes, misleading area/volume, decorative 3D, and selective omission. Include readable sources and necessary detail. Make meaning understandable without color alone.

For editable PPTX, use native text, shapes, tables, and charts where feasible. Do not flatten every slide for visual fidelity. If a complex illustration must be raster, preserve surrounding editability and disclose that limit. Check font availability/fallback and opening in the target application when available.

## Accessibility and verification

Provide unique meaningful titles, logical reading order, useful alt text, descriptive links, contrast, and accessible media. Built-in layouts help structure but still need verification after customization. Check chart/table alternatives and decorative grouping. Visual stacking does not reliably establish reading order; inspect the actual application's structure/tools when available.

Render all slides. Inspect a contact sheet for rhythm/consistency and individual previews at intended size. Correct clipping, overflow, substitution, weak contrast, overlap, and alignment defects. Check the editable file and exports: rendering alone verifies neither reading order nor editability. Run the application accessibility checker plus relevant manual/assistive checks where available; state missing coverage.

## Sources

Reviewed 2026-10-27. Accessible research abstracts/summaries were reviewed; do not imply a full-text review.

- [Mayer: Using multimedia for e-learning](https://onlinelibrary.wiley.com/doi/10.1111/jcal.12197) — peer-reviewed review, 2017-06-13; JCAL 33, 403-423. Abstract/lay summary cover these principles and boundary conditions.
- [Fiorella and Mayer: Reducing Extraneous Processing](https://www.cambridge.org/core/books/abs/cambridge-handbook-of-multimedia-learning/principles-for-reducing-extraneous-processing-in-multimedia-learning/F29A19FCD34C542806F736E0661C05F5) — online 2021-11-19; [DOI 10.1017/9781108894333.019](https://doi.org/10.1017/9781108894333.019). Summary covers coherence, signaling, redundancy, and contiguity; segmenting is covered by Mayer's review. Consult primary research for stronger claims/unfamiliar contexts.
- [Microsoft: Accessible PowerPoint](https://support.microsoft.com/en-us/accessibility/powerpoint/make-your-powerpoint-presentations-accessible-to-people-with-disabilities) — living, version-specific instructions. Recheck relevant application/platform before using checker, menu, or reading-order procedures.
