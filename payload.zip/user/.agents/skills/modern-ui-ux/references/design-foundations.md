# Design foundations

Use when choosing a direction or diagnosing communication and hierarchy. These are decision tools, not an aesthetic recipe.

## Frame the task

Identify who must understand or do what, in which environment, with what prior knowledge, language, access needs, and time pressure. Separate supplied evidence from audience assumptions. A phone outdoors, a classroom projector, an operational table, and a printed booklet need different choices.

Establish the main action/takeaway, necessary evidence, and optional detail. Build information architecture around recognizable tasks and terms. Group and sequence information so readers find a starting point, understand relationships, and know what comes next. Use progressive disclosure for secondary detail without hiding essential conditions or consequences.

## Make decisions explainable

| Decision | Useful questions |
| --- | --- |
| Hierarchy and scale | Does the first thing noticed deserve that attention? Does relative size clarify importance or exaggerate a claim? |
| Gestalt and grouping | Do proximity, similarity, continuity, and enclosure reflect real relationships? Are unrelated items accidentally grouped? |
| Contrast | Which distinction needs emphasis: action, category, status, or reading level? Does it survive grayscale and a busy background? |
| Balance and composition | Where does visual weight collect? Does symmetry or asymmetry serve the tone and reading path? |
| Grid and alignment | Which shared edges, columns, and baselines organize this content? When does a deliberate break improve understanding? |
| Whitespace | Does space separate groups, support legibility, or create pacing? Is important content needlessly pushed away? |
| Brand identity | Which marks, colors, type, image treatments, and voice are authoritative? Is variation within the brief? |

These applications are contextual judgments. Do not present a fixed number of type sizes, columns, cards, colors, or spacing units as scientific law. Retain meaningful variation across a sequence while keeping repeated functions recognizable.

## Typography and clarity

Choose available fonts with appropriate glyph/language coverage and known usage rights. Establish roles for titles, body, labels, captions, and data. Set relative scale, weight, line measure, spacing, and emphasis against actual content and viewing size. Test long headings, diacritics, numerals, and fallback fonts. Nominal point size alone does not establish legibility.

Use predictable text alignment. Avoid fragile manual line breaks in adaptive layouts; deliberate editorial breaks can work in fixed artwork when exports preserve them. Place labels, units, conditions, and captions near what they explain. Reduce cognitive load through visible relationships, concise language, and available context; do not remove necessary detail to make a layout sparse.

Preserve factual copy and distinguish edits from original quotations. Verify names, numbers, dates, units, and intended calls to action. Improve clarity without inventing promises or changing meaning. User/comprehension tests can validate a design hypothesis; an attractive mockup cannot alone demonstrate improved learning, conversion, or usability.

## Sources

Reviewed 2026-10-27. The practical questions above are design synthesis, not a validated scoring system.

- [NN/G: 5 Principles of Visual Design](https://www.nngroup.com/articles/principles-visual-design/) — published 2020-03-01; reviewed 2026-09-01. Practitioner guidance on scale, hierarchy, balance, contrast, and Gestalt. Revisit for source-specific claims; no fixed composition is mandated.
- [GOV.UK: Understand content design](https://guidance.publishing.service.gov.uk/writing-to-gov-uk-standards/plan-manage-content/understand-content-design/) — living guidance; no publication date shown at review. Supports user needs and appropriate content formats. Its house style is not a universal brand requirement.
- [W3C WAI: Images Tutorial](https://www.w3.org/WAI/tutorials/images/) — living guidance. Choose alternatives by image purpose; revisit for unfamiliar image types or accessibility requirements.
