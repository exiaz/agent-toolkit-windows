import { createReadStream, existsSync, readdirSync, statSync, realpathSync } from 'node:fs';
import { createInterface } from 'node:readline';
import { DatabaseSync } from 'node:sqlite';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const home = os.homedir();
const roots = {
  codex: process.env.CODEX_HOME || path.join(home, '.codex'),
  claude: process.env.CLAUDE_CONFIG_DIR || path.join(home, '.claude'),
  antigravity: path.join(home, '.gemini', 'antigravity'),
};
const uuid = /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
const normalized = value => path.resolve(value.replace(/^\\\\\?\\/, '')).replaceAll('\\', '/').toLowerCase().replace(/\/$/, '');
const sameProject = (actual, requested) => !requested || normalized(actual) === normalized(requested);

function database(file, callback) {
  if (!existsSync(file)) throw new Error(`History store unavailable: ${file}`);
  const db = new DatabaseSync(file, { readOnly: true });
  try { return callback(db); } finally { db.close(); }
}

async function records(file, visit) {
  const lines = createInterface({ input: createReadStream(file), crlfDelay: Infinity });
  let pending;
  for await (const line of lines) {
    if (!line.trim()) continue;
    if (pending) throw new Error(`Malformed JSONL record in ${file}`);
    let record;
    try { record = JSON.parse(line); }
    catch { pending = line; continue; }
    visit(record);
  }
  // shortcut: an active writer may leave its final line unfinished; retry after it flushes.
  return { incompleteTail: Boolean(pending) };
}

export function textContent(content) {
  if (typeof content === 'string') return content;
  if (!Array.isArray(content)) return '';
  return content.filter(item => ['text', 'input_text', 'output_text'].includes(item?.type))
    .map(item => typeof item.text === 'string' ? item.text : '').filter(Boolean).join('\n');
}

export function messages(provider, input) {
  return input.flatMap(record => {
    const message = provider === 'codex'
      ? record.type === 'response_item' && record.payload?.type === 'message' ? record.payload : undefined
      : ['user', 'assistant'].includes(record.type) && !record.isSidechain && !record.isMeta && !record.isCompactSummary ? record.message : undefined;
    if (!message || !['user', 'assistant'].includes(message.role) || (message.role === 'assistant' && message.channel && !['final', 'commentary'].includes(message.channel))) return [];
    const text = textContent(message.content);
    return text ? [{ role: message.role, text, timestamp: record.timestamp ?? null }] : [];
  });
}

function codexRows() {
  return database(path.join(roots.codex, 'state_5.sqlite'), db => db.prepare(
    "SELECT id,coalesce(nullif(name,''),title) title,cwd project,updated_at,rollout_path source FROM threads WHERE archived=0 AND (thread_source IS NULL OR thread_source='user') ORDER BY updated_at DESC"
  ).all().map(row => ({ ...row, provider: 'codex', updatedAt: new Date(row.updated_at * 1000).toISOString() })));
}

function claudeFiles(project) {
  const directory = path.join(roots.claude, 'projects');
  if (!existsSync(directory)) throw new Error(`History store unavailable: ${directory}`);
  const slug = project && project.replace(/^\\\\\?\\/, '').replace(/[^a-z0-9]/gi, '-').toLowerCase();
  return readdirSync(directory, { withFileTypes: true }).filter(entry => entry.isDirectory() && (!slug || entry.name.toLowerCase() === slug))
    .flatMap(entry => readdirSync(path.join(directory, entry.name)).filter(file => uuid.test(file.replace(/\.jsonl$/, '')) && file.endsWith('.jsonl'))
      .map(file => { const source = path.join(directory, entry.name, file); return { id: file.slice(0, -6), source, modified: statSync(source).mtimeMs }; }))
    .sort((a, b) => b.modified - a.modified);
}

async function claudeRows(project, limit, onError) {
  const rows = [];
  for (const file of claudeFiles(project).slice(0, limit)) {
    try {
      let cwd, title, firstUser;
      await records(file.source, record => {
        cwd ||= record.cwd;
        title = record.customTitle || record.aiTitle || title;
        firstUser ||= messages('claude', [record]).find(message => message.role === 'user')?.text.slice(0, 120);
      });
      if (!cwd || !sameProject(cwd, project) || !firstUser) continue;
      rows.push({ provider: 'claude', id: file.id, title: title || firstUser,
        project: cwd, source: file.source, updatedAt: new Date(file.modified).toISOString() });
    } catch (error) { onError({ provider: 'claude', source: file.source, error: error.message }); }
  }
  return rows;
}

function agRows() {
  return database(path.join(roots.antigravity, 'conversation_summaries.db'), db => db.prepare(
    'SELECT conversation_id id,title,workspace_uris,last_modified_time updatedAt,not_fully_idle active FROM conversation_summaries WHERE parent_conversation_id=\'\' ORDER BY last_modified_time DESC'
  ).all().map(row => ({ ...row, provider: 'antigravity', project: JSON.parse(row.workspace_uris || '[]').map(uri => uri.startsWith('file:') ? fileURLToPath(uri) : uri), source: path.join(roots.antigravity, 'conversation_summaries.db') })));
}

function projectMatches(row, project) {
  return (Array.isArray(row.project) ? row.project : [row.project]).some(value => sameProject(value, project));
}

function inside(file, root) {
  const relative = path.relative(normalized(realpathSync(root)), normalized(realpathSync(file)));
  return relative !== '' && !relative.startsWith('..') && !path.isAbsolute(relative);
}

export async function list(project, limit) {
  const sessions = [], unavailable = [];
  for (const [provider, read] of Object.entries({ codex: codexRows, claude: () => claudeRows(project, limit, error => unavailable.push(error)), antigravity: agRows })) {
    try { sessions.push(...(await read()).filter(row => projectMatches(row, project)).map(row => ({ ...row, title: row.title.slice(0, 200) }))); }
    catch (error) { unavailable.push({ provider, error: error.message }); }
  }
  return { readOnly: true, sessions: sessions.sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt)).slice(0, limit), unavailable };
}

export async function read(provider, id, limit) {
  if (!Object.hasOwn(roots, provider) || !uuid.test(id)) throw new Error('Use provider codex|claude|antigravity and a valid session UUID.');
  if (provider === 'antigravity') {
    const chunks = database(path.join(roots.antigravity, 'conversation_summaries.db'), db => db.prepare(
      'SELECT chunk_index chunk,user_body,agent_body FROM conversations_fts WHERE conversation_id=? AND chunk_index>=0 ORDER BY chunk_index'
    ).all(id));
    if (!chunks.length) throw new Error('No indexed conversation text found. AG may not have indexed this session yet.');
    return { provider, id, readOnly: true, fidelity: 'search_index_grouped_by_chunk_and_role', warning: 'Indexed text may lag and does not preserve exact turn order.',
      messages: bounded(chunks.flatMap(chunk => [{ role: 'user', text: chunk.user_body, chunk: chunk.chunk }, { role: 'assistant', text: chunk.agent_body, chunk: chunk.chunk }]).filter(item => item.text?.trim()), limit) };
  }
  const row = provider === 'codex'
    ? database(path.join(roots.codex, 'state_5.sqlite'), db => db.prepare('SELECT rollout_path source FROM threads WHERE id=?').get(id))
    : claudeFiles().find(file => file.id === id);
  if (!row || !inside(row.source, roots[provider])) throw new Error('Session not found in this provider history store.');
  let recent = [];
  const data = await records(row.source, record => { recent = bounded([...recent, ...messages(provider, [record])], limit); });
  return { provider, id, readOnly: true, source: row.source, incompleteTail: data.incompleteTail, messages: recent };
}

export function bounded(input, limit) {
  let remaining = 60000;
  return input.slice(-limit).reverse().flatMap(message => {
    if (!remaining) return [];
    const size = Math.min(12000, remaining);
    const text = message.text.slice(0, size);
    remaining -= text.length;
    return [{ ...message, text, ...(text.length < message.text.length ? { truncated: true } : {}) }];
  }).reverse();
}

export async function main(args) {
  const command = args.shift();
  const positional = [], options = {};
  while (args.length) {
    const value = args.shift();
    if (value.startsWith('--')) {
      if (!['--project', '--limit'].includes(value) || !args.length) throw new Error('Supported options: --project PATH, --limit 1..100.');
      options[value.slice(2)] = args.shift();
    } else positional.push(value);
  }
  const limit = Number(options.limit ?? (command === 'list' ? 20 : 40));
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100) throw new Error('Limit must be 1..100.');
  if (command === 'list' && !positional.length) return list(options.project, limit);
  if (command === 'read' && positional.length === 2 && !options.project) return read(positional[0], positional[1], limit);
  throw new Error('Usage: history.mjs list [--project PATH] [--limit N] | read codex|claude|antigravity UUID [--limit N]');
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try { console.log(JSON.stringify(await main(process.argv.slice(2)), null, 2)); }
  catch (error) { console.error(JSON.stringify({ error: error.message })); process.exitCode = 1; }
}
