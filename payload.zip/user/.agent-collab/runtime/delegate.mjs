import {spawn, spawnSync} from 'node:child_process';
import {existsSync, mkdirSync, readFileSync, writeFileSync, copyFileSync, lstatSync, readdirSync} from 'node:fs';
import {createHash, randomUUID} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createCoord, canonical, within} from './coord.mjs';
import {workspace,localGuard} from './workspace.mjs';
const output=o=>process.stdout.write(JSON.stringify(o,null,2)+'\n');
const fail=(code,message)=>{output({status:'error',code,message});process.exit(1);};
const opt={};
for(let i=2;i<process.argv.length;i++) { const key=process.argv[i]; if(!['--to','--mode','--prompt-file','--cwd','--scope','--timeout','--session','--agent'].includes(key)||!process.argv[i+1]) fail('BAD_ARGS','Use --to claude|codex --mode read|write --prompt-file FILE [--cwd DIR] [--scope FILE,...] [--timeout SECONDS].'); opt[key.slice(2)]=process.argv[++i]; }
if(process.env.AGENT_COLLAB_DELEGATED==='1') fail('NESTED_DELEGATION','Workers cannot delegate.');
const cwd=workspace(path.resolve(opt.cwd??process.cwd())), to=opt.to, mode=opt.mode??'read';
if(!['codex','claude'].includes(to)) fail('NOT_SUPPORTED','No verified safe Antigravity CLI is installed. agentapi is not enabled for delegation.');
if(!['read','write'].includes(mode)||!opt['prompt-file']) fail('BAD_ARGS','Mode and prompt-file are required.');
const timeout=Number(opt.timeout??180)*1000;
if(!Number.isSafeInteger(timeout)||timeout<1000||timeout>900000) fail('BAD_ARGS','Timeout must be 1..900 seconds.');
// Existing local coordinators keep ownership of their delegation workflow.
if(localGuard(cwd,'claude') && localGuard(cwd,'codex')) fail('LOCAL_COORDINATOR','Use the local project delegation workflow.');
const coord=createCoord(cwd);
const identity={session:opt.session??process.env.AGENT_COLLAB_NATIVE_SESSION_ID??process.env.CODEX_THREAD_ID??process.env.CODEX_SESSION_ID, agent:opt.agent??process.env.AGENT_COLLAB_NATIVE_AGENT??((process.env.CODEX_THREAD_ID||process.env.CODEX_SESSION_ID)?'codex':null),worktree:cwd};
let parent; try {parent=coord.parent(identity);} catch(e){fail(e.code??'COORD',e.message);}
if(identity.agent===to) fail('SAME_AGENT','Use native task tools for the same agent.');
const task=`${to}-${randomUUID()}`, dir=fileURLToPath(new URL(`../state/reports/${task}/`,import.meta.url));
let scopes=[];
try {
 if(mode==='write') {
  scopes=(opt.scope??'').split(',').filter(Boolean).map(p=>canonical(path.resolve(cwd,p)));
  if(!scopes.length) throw Error('Write mode requires explicit file scopes.');
  for(const p of scopes){
   if(!within(p,cwd)||p===cwd||/(?:^|\/)(?:\.git|\.agents|\.claude|\.codex|\.gemini|\.agent-collab)(?:\/|$)/.test(p)) throw Error('Invalid or protected file scope.');
   if(existsSync(p)&&!lstatSync(p).isFile()) throw Error('Scope must be a regular file, not a directory or symlink.');
  }
 }
 coord.open({id:task,parent,parentIdentity:identity,agent:to,role:mode==='read'?'reviewer':'worker',mode,worktree:cwd,scopes,fixed:mode==='write',pid:process.pid});
 mkdirSync(dir,{recursive:true});
 const backup=scopes.map((file,i)=>{const existed=existsSync(file); if(existed) copyFileSync(file,path.join(dir,`${i}.before`));return {file,existed,backup:existed?path.join(dir,`${i}.before`):null};});
 writeFileSync(path.join(dir,'backup.json'),JSON.stringify(backup,null,2));
} catch(e) {coord.release(task);fail(e.code??'BACKUP',e.message);}
let bin,args;
if(to==='codex'){
 const js=path.join(process.env.APPDATA??'', 'npm/node_modules/@openai/codex/bin/codex.js');
 if(!existsSync(js)){coord.release(task);fail('CLI_UNAVAILABLE','Installed Codex node entrypoint is unavailable.');}
 bin=process.execPath; args=[js,'--no-daemon','exec','--cd',cwd,'--sandbox',mode==='read'?'read-only':'workspace-write','--skip-git-repo-check','--ephemeral','-o',path.join(dir,'last.txt'),'-'];
} else {
 const hit=spawnSync('where.exe',['claude.exe'],{encoding:'utf8',windowsHide:true}).stdout?.trim().split(/\r?\n/)[0];
 const packages=path.join(process.env.LOCALAPPDATA??'','Microsoft/WinGet/Packages');
 const fallback=existsSync(packages)?readdirSync(packages).find(n=>n.startsWith('Anthropic.ClaudeCode')):null;
 bin=hit||(fallback&&path.join(packages,fallback,'claude.exe'));
 if(!bin||!existsSync(bin)){coord.release(task);fail('CLI_UNAVAILABLE','Claude executable unavailable.');}
 args=['-p','--output-format','text','--no-session-persistence','--permission-mode',mode==='read'?'plan':'acceptEdits'];
}
let prompt;
try {prompt=readFileSync(path.resolve(opt['prompt-file']),'utf8');} catch(e){coord.release(task);fail('PROMPT',e.message);}
const env={...process.env,AGENT_COLLAB_DELEGATED:'1',AGENT_COLLAB_TASK_ID:task,AGENT_COLLAB_MODE:mode,AGENT_COLLAB_WORKER_PID:String(process.pid)};
for(const key of ['AGENT_COLLAB_NATIVE_SESSION_ID','AGENT_COLLAB_NATIVE_AGENT','CODEX_THREAD_ID','CODEX_SESSION_ID','CLAUDE_ENV_FILE','CODEX_APP_RUNTIME_CLI_PATH','CODEX_APP_TOOLS_PIPE_PATH','CODEX_INTERNAL_ORIGINATOR_OVERRIDE','CODEX_TOOL_CALL_ID','CODEX_WINDOWS_REGISTERED_CORE','CODEX_WINDOWS_SANDBOX_PACKAGE_FAMILY','CODEX_TASK_WORKSPACE_VERIFYING_IDENTITY']) delete env[key];
const preamble=`Explicit delegated ${mode} task. Do not delegate or invoke other agents. Do not commit, push, merge, change branches, agent settings, authentication or permissions. ${mode==='write'?'Use structured file tools only; no shell writes. Scope: '+scopes.join(', '):'Read-only; do not write any file.'} Report result and actual checks briefly.\n\n`;
let hooksVerified=false;
const digest=file=>existsSync(file)&&lstatSync(file).isFile()?createHash('sha256').update(readFileSync(file)).digest('hex'):null;
let child, timer, heartbeat, finished=false, cancelled=false, exitCode=null, stdout='', stderr='';
const stop=()=>{cancelled=true;if(!child?.pid||finished)return;if(process.platform==='win32')spawnSync('taskkill.exe',['/PID',String(child.pid),'/T','/F'],{windowsHide:true,stdio:'ignore',timeout:10000});else child.kill('SIGTERM');};
process.once('SIGINT',stop);process.once('SIGTERM',stop);
try {
 exitCode=await new Promise((resolve,reject)=>{
  child=spawn(bin,args,{cwd,env,windowsHide:true,stdio:['pipe','pipe','pipe']});
  child.stdout.on('data',b=>{stdout=(stdout+b).slice(-65536);});child.stderr.on('data',b=>{stderr=(stderr+b).slice(-8192);});
  child.stdin.on('error',()=>{});child.once('error',reject);child.once('close',code=>{finished=true;resolve(code);});
  timer=setTimeout(stop,timeout);heartbeat=setInterval(()=>{try{coord.renew(task,process.pid);}catch{stop();}},30000);
  child.stdin.end(preamble+prompt);
 });
} catch(e){stderr=e.message;stop();} finally {clearTimeout(timer);clearInterval(heartbeat);if(!finished)stop();hooksVerified=!!coord.get(task)?.nativeSession;
 const backups=JSON.parse(readFileSync(path.join(dir,'backup.json'),'utf8'));
 for(const item of backups) item.after_sha256=digest(item.file);
 writeFileSync(path.join(dir,'backup.json'),JSON.stringify(backups,null,2));
 coord.release(task);}
const summary=to==='codex'&&existsSync(path.join(dir,'last.txt'))?readFileSync(path.join(dir,'last.txt'),'utf8'):stdout;
const result={status:cancelled?'cancelled':exitCode!==0?'failed':hooksVerified?'ok':'hooks-unverified',hooksVerified,task,parent,agent:to,mode,workspace:cwd,exitCode,summary:summary.trim().slice(-12000),error:exitCode===0?undefined:stderr.slice(-2000),backup:path.join(dir,'backup.json')};
writeFileSync(path.join(dir,'result.json'),JSON.stringify(result,null,2));output(result);process.exitCode=exitCode===0&&!cancelled&&hooksVerified?0:1;
