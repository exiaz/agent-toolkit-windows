import path from 'node:path';
import {realpathSync} from 'node:fs';
export function canonical(value){
  let current=path.resolve(value),suffix=[];
  for(;;){
    try{current=path.join(realpathSync.native(current),...suffix);break;}
    catch{const parent=path.dirname(current);if(parent===current)break;suffix.unshift(path.basename(current));current=parent;}
  }
  const normalized=current.replace(/\\/g,'/').replace(/\/$/,'');
  return process.platform==='win32'?normalized.toLowerCase():normalized;
}
export const within=(file,dir)=>file===dir||file.startsWith(dir+'/');
