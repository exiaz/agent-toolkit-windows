import {execFileSync} from 'node:child_process';
import {existsSync, readFileSync} from 'node:fs';
import path from 'node:path';
import {canonical} from './paths.mjs';
export function workspace(cwd) {
  try { return canonical(execFileSync('git', ['rev-parse','--show-toplevel'], {cwd, encoding:'utf8', windowsHide:true, timeout:3000, stdio:['ignore','pipe','ignore']}).trim()); }
  catch { return canonical(cwd); }
}
export function localGuard(root, agent) {
  const file = path.join(root, agent === 'codex' ? '.codex/hooks.json' : '.claude/settings.json');
  try {
    const hooks = JSON.parse(readFileSync(file,'utf8')).hooks;
    return ['SessionStart','PreToolUse','PostToolUse','Stop'].every(event => hooks?.[event]?.some(group => group.hooks?.some(h => h.command?.includes('.agents/hooks/collab-guard.mjs')))) && existsSync(path.join(root,'.agents/hooks/collab-guard.mjs'));
  } catch { return false; }
}
