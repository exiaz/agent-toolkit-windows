import {readFileSync,writeFileSync,existsSync,lstatSync,unlinkSync,copyFileSync} from 'node:fs';
import {createHash,randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {createCoord,canonical,within} from './coord.mjs';
const task=process.argv[2];
if(process.argv.length!==3||! /^(claude|codex)-[a-f0-9-]{36}$/.test(task??'')) throw Error('Use: node restore.mjs TASK_ID (after reviewing backup.json).');
const dir=fileURLToPath(new URL(`../state/reports/${task}/`,import.meta.url));
const result=JSON.parse(readFileSync(path.join(dir,'result.json'),'utf8'));
const backups=JSON.parse(readFileSync(path.join(dir,'backup.json'),'utf8'));
if(result.mode!=='write'||!backups.length)throw Error('No write backup to restore.');
const project=canonical(result.workspace),coord=createCoord(project),id='restore-'+randomUUID();
for(const item of backups) {
 if(canonical(item.file)!==item.file||!within(item.file,project)||item.file===project||/(?:^|\/)(?:\.git|\.agents|\.claude|\.codex|\.gemini|\.agent-collab)(?:\/|$)/.test(item.file))throw Error('Invalid backup target.');
 if(item.existed&&(!item.backup||!within(canonical(item.backup),canonical(dir))))throw Error('Invalid backup source.');
 if(!Object.hasOwn(item,'after_sha256'))throw Error('Backup predates safe restore metadata; compare manually.');
}
coord.open({id,agent:'restore',role:'operator',mode:'write',worktree:project,scopes:backups.map(b=>b.file),pid:process.pid});
try {
 for(const item of backups) {
  if(existsSync(item.file)&&!lstatSync(item.file).isFile())throw Error('Target is no longer a regular file.');
  const current=existsSync(item.file)?createHash('sha256').update(readFileSync(item.file)).digest('hex'):null;
  if(current!==item.after_sha256)throw Error('Target changed after worker completion; manual merge required: '+item.file);
  if(item.existed&&!existsSync(item.backup))throw Error('Backup file missing.');
 }
 // Validate every target first; retain post-worker copies before restoring.
 for(const [index,item] of backups.entries()) if(existsSync(item.file)) copyFileSync(item.file,path.join(dir,`${index}.before-restore`));
 for(const item of backups) {if(item.existed)writeFileSync(item.file,readFileSync(item.backup));else if(existsSync(item.file))unlinkSync(item.file);}
 process.stdout.write(JSON.stringify({status:'restored',task,files:backups.map(b=>b.file)})+'\n');
} finally {coord.release(id);}
