import test from 'node:test';
import {createHash,randomUUID} from 'node:crypto';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,cpSync,writeFileSync,readFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {spawn,spawnSync,execFileSync} from 'node:child_process';
const base=mkdtempSync(path.join(tmpdir(),'agent-collab-test-'));
const runtime=path.join(base,'runtime');cpSync(path.dirname(fileURLToPath(import.meta.url)),runtime,{recursive:true});
const {createCoord,canonical,sessionTaskId}=await import(pathToFileURL(path.join(runtime,'coord.mjs')));
const a=path.join(base,'project-a'),b=path.join(base,'project-b');mkdirSync(a);mkdirSync(b);mkdirSync(path.join(a,'sub'));
const coord=createCoord(a);let seq=0;
const invoke=(agent,session,event,tool,args={},cwd=a,env={})=>{
 const p=agent==='antigravity'?{conversationId:session,workspacePaths:[cwd],stepIdx:++seq,toolCall:{name:tool,args}}:{session_id:session,hook_event_name:event,tool_name:tool,tool_input:args,tool_use_id:'t'+ ++seq,cwd};
 const x=spawnSync(process.execPath,[path.join(runtime,'guard.mjs'),agent,...(agent==='antigravity'?[event]:[])],{cwd,input:JSON.stringify(p),encoding:'utf8',env:{...process.env,AGENT_COLLAB_DELEGATED:'',...env},windowsHide:true});
 assert.equal(x.status,0,x.stderr);return x.stdout?JSON.parse(x.stdout):{};
};
const pre=(agent,session,file,cwd=a,env={})=>invoke(agent,session,'PreToolUse',agent==='antigravity'?'write_to_file':'Write',agent==='antigravity'?{TargetFile:file}:{file_path:file},cwd,env);
const denied=x=>(x.hookSpecificOutput?.permissionDecision??x.decision)==='deny';
const end=(agent,s)=>invoke(agent,s,'Stop');
test.after(()=>rmSync(base,{recursive:true,force:true}));

test('Local coordinator delegation keeps its own workflow',()=>{
 const local=path.join(base,'local-delegation');mkdirSync(path.join(local,'.agents/hooks'),{recursive:true});mkdirSync(path.join(local,'.claude'));mkdirSync(path.join(local,'.codex'));
 const hooks=Object.fromEntries(['SessionStart','PreToolUse','PostToolUse','Stop'].map(event=>[event,[{hooks:[{command:'node .agents/hooks/collab-guard.mjs'}]}]]));
 writeFileSync(path.join(local,'.agents/hooks/collab-guard.mjs'),'');writeFileSync(path.join(local,'.claude/settings.json'),JSON.stringify({hooks}));writeFileSync(path.join(local,'.codex/hooks.json'),JSON.stringify({hooks}));
 const prompt=path.join(local,'task.txt');writeFileSync(prompt,'Read fixture only.');
 const result=spawnSync(process.execPath,[path.join(runtime,'delegate.mjs'),'--to','claude','--mode','read','--prompt-file',prompt,'--cwd',local],{encoding:'utf8',windowsHide:true,env:{...process.env,AGENT_COLLAB_DELEGATED:''}});
 assert.equal(result.status,1,result.stderr);assert.equal(JSON.parse(result.stdout).code,'LOCAL_COORDINATOR');
});


test('Codex, Claude and Antigravity conflict on the same canonical file',()=>{
 assert.equal(denied(pre('codex','one',path.join(a,'x.txt'))),false);
 assert.equal(denied(pre('claude','two',path.join(a,'x.txt'))),true);
 assert.equal(denied(pre('antigravity','three',path.join(a,'x.txt'))),true);
 assert.equal(denied(pre('claude','four',path.join(b,'x.txt'),b)),false);
 end('codex','one');end('claude','two');end('antigravity','three');end('claude','four');
});
test('Nested non-Git cwd cannot bypass absolute file reservations',()=>{
 pre('claude','nested-a',path.join(a,'sub/x.txt'));
 assert.equal(denied(pre('codex','nested-b','x.txt',path.join(a,'sub'))),true);
 end('claude','nested-a');end('codex','nested-b');
});
test('Windows path case and sibling names preserve boundaries',()=>{
 pre('codex','case-a',path.join(a,'ABC.txt'));
 assert.equal(denied(pre('claude','case-b',path.join(a,'abc.txt'))),process.platform==='win32');
 assert.equal(denied(pre('claude','case-c',path.join(a,'ABC.txt.other'))),false);
 for(const [agent,id] of [['codex','case-a'],['claude','case-b'],['claude','case-c']])end(agent,id);
});
test('Reads remain available during another writer claim, including Antigravity allow schema',()=>{
 pre('codex','read-writer',path.join(a,'x.txt'));
 assert.equal(denied(invoke('claude','reader','PreToolUse','Read',{file_path:path.join(a,'x.txt')})),false);
 assert.equal(invoke('antigravity','reader-ag','PreToolUse','view_file',{AbsolutePath:path.join(a,'x.txt')}).decision,'allow');
 end('codex','read-writer');end('claude','reader');end('antigravity','reader-ag');
});
test('Shell writer reservation releases through exact callback identity',()=>{
 const payload={session_id:'shell',hook_event_name:'PreToolUse',tool_name:'Bash',tool_input:{command:'npm test'},tool_use_id:'shell-id',cwd:a};
 const run=p=>spawnSync(process.execPath,[path.join(runtime,'guard.mjs'),'claude'],{input:JSON.stringify(p),encoding:'utf8',windowsHide:true});
 assert.equal(run(payload).status,0);assert.equal(denied(pre('codex','shell-other',path.join(b,'x.txt'),b)),true);
 assert.equal(run({...payload,hook_event_name:'PostToolUse'}).status,0);assert.equal(denied(pre('codex','shell-other',path.join(b,'x.txt'),b)),false);
 end('claude','shell');end('codex','shell-other');
});
test('Scoped worker cannot write outside scope or invoke a shell writer',()=>{
 coord.session({session:'parent',agent:'claude',worktree:canonical(a)});
 const parentIdentity={session:'parent',agent:'claude',worktree:canonical(a)};
 coord.open({id:'worker',parent:sessionTaskId('claude','parent'),parentIdentity,agent:'codex',mode:'write',worktree:canonical(a),scopes:[canonical(path.join(a,'x.txt'))],fixed:true});
 const env={AGENT_COLLAB_DELEGATED:'1',AGENT_COLLAB_TASK_ID:'worker',AGENT_COLLAB_MODE:'write',AGENT_COLLAB_WORKER_PID:String(process.pid)};
 assert.equal(denied(pre('codex','worker-native',path.join(a,'x.txt'),a,env)),false);
 assert.equal(denied(pre('codex','worker-native',path.join(a,'y.txt'),a,env)),true);
 assert.equal(denied(invoke('codex','worker-native','PreToolUse','Bash',{command:'npm test'},a,env)),true);
 assert.equal(denied(invoke('codex','worker-native','PreToolUse','spawn_agent',{},a,env)),true);
 assert.equal(denied(invoke('codex','worker-native','PreToolUse','Bash',{command:'claude -p hello'},a,env)),true);
 assert.throws(()=>coord.parent({session:'worker-native',agent:'codex',worktree:canonical(a)}),{code:'PARENT_UNAUTHORIZED'});
 coord.release('worker');end('claude','parent');
});
test('Read-only workers cannot write; invalid delegated task fails closed',()=>{
 coord.open({id:'read-worker',agent:'codex',mode:'read',worktree:canonical(a)});
 const env={AGENT_COLLAB_DELEGATED:'1',AGENT_COLLAB_TASK_ID:'read-worker',AGENT_COLLAB_MODE:'read',AGENT_COLLAB_WORKER_PID:String(process.pid)};
 assert.equal(denied(pre('codex','read-native',path.join(a,'x.txt'),a,env)),true);
 assert.equal(denied(pre('codex','bad-native',path.join(a,'x.txt'),a,{...env,AGENT_COLLAB_TASK_ID:'missing'})),true);
 coord.release('read-worker');
});
test('Git workspace resolved without changing its branch',()=>{
 execFileSync('git',['init','-q','-b','fixture'],{cwd:b,windowsHide:true});
 invoke('claude','git','SessionStart',undefined,{},b);
 assert.equal(execFileSync('git',['branch','--show-current'],{cwd:b,encoding:'utf8',windowsHide:true}).trim(),'fixture');
 pre('codex','git-file',path.join(b,'x.txt'),b);assert.equal(denied(pre('antigravity','git-ag',path.join(b,'x.txt'),b)),true);
 end('codex','git-file');end('antigravity','git-ag');end('claude','git');
});
test('Local project registrations cause a true global no-op',()=>{
 const local=path.join(base,'local');mkdirSync(local);mkdirSync(path.join(local,'.claude'));mkdirSync(path.join(local,'.agents/hooks'),{recursive:true});
 writeFileSync(path.join(local,'.agents/hooks/collab-guard.mjs'),'');
 const hooks=Object.fromEntries(['SessionStart','PreToolUse','PostToolUse','Stop'].map(e=>[e,[{hooks:[{command:'node "$CLAUDE_PROJECT_DIR/.agents/hooks/collab-guard.mjs" claude'}]}]]));
 writeFileSync(path.join(local,'.claude/settings.json'),JSON.stringify({hooks}));
 const before=readFileSync(path.join(base,'state/coord/state.json'),'utf8');invoke('claude','local-skip','SessionStart',undefined,{},local);
 assert.equal(readFileSync(path.join(base,'state/coord/state.json'),'utf8'),before);
});
test('Dead expired task reaped; living expired task retained; no worker auto-spawn',()=>{
 coord.open({id:'alive',agent:'codex',worktree:canonical(a),scopes:[canonical(path.join(a,'alive.txt'))],pid:process.pid});
 coord.open({id:'dead',agent:'claude',worktree:canonical(a),scopes:[canonical(path.join(a,'dead.txt'))],pid:2147483647});
 const stateFile=path.join(base,'state/coord/state.json'), state=JSON.parse(readFileSync(stateFile,'utf8'));
 state.tasks.alive.leaseUntil=0;state.tasks.dead.leaseUntil=0;writeFileSync(stateFile,JSON.stringify(state));
 const tasks=coord.list();assert.equal(tasks.some(t=>t.id==='alive'),true);assert.equal(tasks.some(t=>t.id==='dead'),false);
 assert.equal(tasks.some(t=>t.parent),false);coord.release('alive');
});

test('Shell read bypasses cannot escape read-only workers',()=>{
 coord.open({id:'shell-read',agent:'claude',mode:'read',worktree:canonical(a)});
 const env={AGENT_COLLAB_DELEGATED:'1',AGENT_COLLAB_TASK_ID:'shell-read',AGENT_COLLAB_MODE:'read',AGENT_COLLAB_WORKER_PID:String(process.pid)};
 for(const command of ["node evil.js -v", "node -e \"process.exit(0)\" -v", "gci | foreach-object { Remove-Item $_ }", "rg --pre malicious x .", "sed s/x/y/e file", "echo \\\"; rm -rf x; echo \\\""]) assert.equal(denied(invoke('claude','shell-read-native','PreToolUse','Bash',{command},a,env)),true,command);
 assert.equal(denied(invoke('claude','shell-read-native','PreToolUse','Bash',{command:"Get-Content -LiteralPath 'probe.txt' -Raw"},a,env)),false);
 coord.release('shell-read');
});
test('Antigravity background task keeps reservation until fullyIdle Stop',()=>{
 invoke('antigravity','background','PreToolUse','run_command',{CommandLine:'npm test'});
 invoke('antigravity','background','PostToolUse','run_command',{CommandLine:'npm test'});
 assert.equal(denied(pre('claude','background-other',path.join(a,'x.txt'))),true);
 const run=fullyIdle=>spawnSync(process.execPath,[path.join(runtime,'guard.mjs'),'antigravity','Stop'],{input:JSON.stringify({conversationId:'background',workspacePaths:[a],fullyIdle}),encoding:'utf8',windowsHide:true});
 run(false);assert.equal(denied(pre('claude','background-other',path.join(a,'x.txt'))),true);
 run(true);assert.equal(denied(pre('claude','background-other',path.join(a,'x.txt'))),false);end('claude','background-other');
});

test('Concurrent recovery of one dead mutex preserves atomic conflict exclusion',async()=>{
 const mutex=path.join(base,'state/coord/mutex');mkdirSync(mutex);writeFileSync(path.join(mutex,'owner'),'2147483647');
 const code=`import {createCoord,canonical} from ${JSON.stringify(pathToFileURL(path.join(runtime,'coord.mjs')).href)}; const c=createCoord(${JSON.stringify(a)});try{c.open({id:process.argv[1],agent:'test',worktree:canonical(${JSON.stringify(a)}),scopes:[canonical(${JSON.stringify(path.join(a,'race.txt'))})],pid:${process.pid}});console.log('claimed');}catch(e){console.log(e.code);}`;
 const results=await Promise.all(Array.from({length:8},(_,i)=>new Promise((resolve,reject)=>{const p=spawn(process.execPath,['--input-type=module','-e',code,'race-'+i],{windowsHide:true});let out='';p.stdout.on('data',b=>out+=b);p.on('error',reject);p.on('close',code=>resolve({code,out:out.trim()}));})));
 assert.equal(results.filter(r=>r.out==='claimed').length,1,JSON.stringify(results));assert.equal(results.filter(r=>r.out==='SCOPE_CONFLICT').length,7,JSON.stringify(results));
 for(let i=0;i<8;i++)coord.release('race-'+i);
});

test('Safe restore preserves backups, refuses later edits and respects active reservations',()=>{
 const task='codex-'+randomUUID(),dir=path.join(base,'state/reports',task);mkdirSync(dir,{recursive:true});
 const target=canonical(path.join(a,'restore-existing.txt')),fresh=canonical(path.join(a,'restore-new.txt'));
 writeFileSync(target,'after');writeFileSync(fresh,'created');writeFileSync(path.join(dir,'0.before'),'before');
 const sha=s=>createHash('sha256').update(s).digest('hex');
 const manifest=[{file:target,existed:true,backup:path.join(dir,'0.before'),after_sha256:sha('after')},{file:fresh,existed:false,backup:null,after_sha256:sha('created')}];
 writeFileSync(path.join(dir,'backup.json'),JSON.stringify(manifest));writeFileSync(path.join(dir,'result.json'),JSON.stringify({workspace:canonical(a),mode:'write'}));
 const restore=()=>spawnSync(process.execPath,[path.join(runtime,'restore.mjs'),task],{encoding:'utf8',windowsHide:true});
 coord.open({id:'restore-blocker',agent:'test',worktree:canonical(a),scopes:[target]});
 assert.notEqual(restore().status,0);assert.equal(readFileSync(target,'utf8'),'after');coord.release('restore-blocker');
 writeFileSync(target,'later-user-edit');assert.notEqual(restore().status,0);assert.equal(readFileSync(target,'utf8'),'later-user-edit');assert.equal(readFileSync(fresh,'utf8'),'created');
 writeFileSync(target,'after');const restored=restore();assert.equal(restored.status,0,restored.stderr);assert.equal(readFileSync(target,'utf8'),'before');
 assert.throws(()=>readFileSync(fresh));assert.equal(readFileSync(path.join(dir,'0.before-restore'),'utf8'),'after');assert.equal(readFileSync(path.join(dir,'1.before-restore'),'utf8'),'created');
});
test('Bridge timeout terminates its owned process tree and releases its task',()=>{
 const mock=path.join(base,'mock-appdata'),bin=path.join(mock,'npm/node_modules/@openai/codex/bin');mkdirSync(bin,{recursive:true});
 const pidfile=path.join(base,'mock-pid.txt');writeFileSync(path.join(bin,'codex.js'),`require('node:fs').writeFileSync(${JSON.stringify(pidfile)},String(process.pid));setInterval(()=>{},1000);`);
 const prompt=path.join(a,'timeout-prompt.txt');writeFileSync(prompt,'Disposable test.');
 coord.session({agent:'claude',session:'timeout-parent',worktree:canonical(a)});
 const result=spawnSync(process.execPath,[path.join(runtime,'delegate.mjs'),'--to','codex','--mode','read','--cwd',a,'--prompt-file',prompt,'--timeout','1'],{encoding:'utf8',windowsHide:true,timeout:15000,env:{...process.env,APPDATA:mock,AGENT_COLLAB_DELEGATED:'',AGENT_COLLAB_NATIVE_AGENT:'claude',AGENT_COLLAB_NATIVE_SESSION_ID:'timeout-parent'}});
 assert.equal(result.status,1,result.stderr);const report=JSON.parse(result.stdout);assert.equal(report.status,'cancelled');assert.equal(coord.get(report.task),null);
 const pid=Number(readFileSync(pidfile,'utf8'));assert.throws(()=>process.kill(pid,0));
});

test('Global Git orchestration keeps native approval policy; delegated Git mutations stay denied',()=>{
 assert.equal(denied(invoke('claude','git-orchestrator','PreToolUse','Bash',{command:'git commit -m fictional-test'})),false);
 end('claude','git-orchestrator');
 coord.open({id:'git-worker',agent:'codex',mode:'write',worktree:canonical(a),scopes:[canonical(path.join(a,'x.txt'))],fixed:true});
 assert.equal(denied(invoke('codex','git-worker-native','PreToolUse','Bash',{command:'git commit -m fictional-test'},a,{AGENT_COLLAB_DELEGATED:'1',AGENT_COLLAB_TASK_ID:'git-worker',AGENT_COLLAB_MODE:'write',AGENT_COLLAB_WORKER_PID:String(process.pid)})),true);coord.release('git-worker');
});
test('Observed Antigravity Path edits normalize to the existing local guard contract',()=>{
 const local=path.join(base,'local');
 writeFileSync(path.join(local,'.agents/hooks/collab-guard.mjs'),`let s='';for await(const c of process.stdin)s+=c;const p=JSON.parse(s);process.stdout.write(JSON.stringify({name:p.toolCall?.name,target:p.toolCall?.args?.TargetFile}));`);
 const r=invoke('antigravity','local-adapter','PreToolUse','edit_file',{Path:path.join(local,'a.txt'),Target:'old',Replacement:'new'},local);
 assert.equal(r.name,'replace_file_content');assert.equal(r.target,path.join(local,'a.txt'));
 assert.equal(denied(invoke('antigravity','local-adapter','PreToolUse','unverified_file_tool',{Path:path.join(local,'a.txt')},local)),true);
});
