import {appendFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createCoord, sessionTaskId, canonical} from './coord.mjs';
import {classifyShell,splitShell} from './policy.mjs';
import {workspace, localGuard} from './workspace.mjs';
const agent=process.argv[2], ag=agent==='antigravity';
if (!['codex','claude','antigravity'].includes(agent)) process.exit(2);
let input;
try { let raw=''; for await (const chunk of process.stdin) raw+=chunk; input=JSON.parse(raw.replace(/^\uFEFF/,'')); if (!input || Array.isArray(input) || typeof input!=='object') throw Error(); }
catch { process.stderr.write('Invalid collaboration hook payload.'); process.exit(2); }
const event=ag?process.argv[3]:input.hook_event_name;
const session=ag?input.conversationId:input.session_id;
const rawArgs=ag?(input.toolCall?.args??{}):(input.tool_input??{});
const args=typeof rawArgs==='string'?{input:rawArgs}:rawArgs;
const tool=ag?input.toolCall?.name:input.tool_name;
const toolId=ag?`${session}:${input.stepIdx}`:input.tool_use_id;
const cwd=ag?(input.workspacePaths?.[0]??process.cwd()):(input.cwd??process.cwd());
const root=workspace(cwd), delegated=process.env.AGENT_COLLAB_DELEGATED==='1';
// Existing project guard remains the sole coordinator for its native agents.
if (!delegated && !ag && localGuard(root,agent)) process.exit(0);
if(ag && event==='Stop' && input.fullyIdle!==true) {process.stdout.write(JSON.stringify({decision:'stop'}));process.exit(0);}
if(ag && event==='PostToolUse' && input.toolCall?.name==='run_command') {process.stdout.write('{}');process.exit(0);}
if (ag && localGuard(root,'claude')) {
  // Installed Antigravity 2.29 edit_file uses Path; translate only the verified file-edit contract.
  if(event==='PreToolUse' && input.toolCall?.args?.Path && !['read_file','edit_file'].includes(input.toolCall.name)) {
    process.stdout.write(JSON.stringify({decision:'deny',reason:'Antigravity file-tool schema is not verified for the local project guard.'}));process.exit(0);
  }
  if(input.toolCall?.name==='edit_file') input={...input,toolCall:{...input.toolCall,name:'replace_file_content',args:{...input.toolCall.args,TargetFile:input.toolCall.args.Path}}};
  const result=spawnSync(process.execPath,[path.join(root,'.agents/hooks/collab-guard.mjs'),'antigravity',event],{cwd:root,input:JSON.stringify(input),encoding:'utf8',windowsHide:true,timeout:8000});
  process.stdout.write(result.stdout??'');process.stderr.write(result.stderr??'');process.exit(result.status??2);
}
const coord=createCoord(root), id=delegated?process.env.AGENT_COLLAB_TASK_ID:sessionTaskId(agent,session);
const meta={agent,pid:delegated?Number(process.env.AGENT_COLLAB_WORKER_PID):process.ppid};
const emit=o=>process.stdout.write(JSON.stringify(o));
const deny=(code,reason)=>{coord.audit('deny',{agent,session,event,tool,code});emit(ag?{decision:'deny',reason:`[agent-collab:${code}] ${reason}`}:{hookSpecificOutput:{hookEventName:'PreToolUse',permissionDecision:'deny',permissionDecisionReason:`[agent-collab:${code}] ${reason}`}});process.exit(0);};
const readTools=new Set(['Read','Glob','Grep','view_file','read_file','list_dir','grep_search','find_by_name','WebSearch','WebFetch','update_plan']);
const shellTools=new Set(['Bash','PowerShell','exec_command','shell','local_shell','run_command','functions.exec_command']);
const delegateTools=new Set(['Agent','Task','invoke_subagent','spawn_agent']);
try {
  if (['SessionStart','PreToolUse'].includes(event)) {
    coord.session({session,agent,worktree:root,delegated});
    if (delegated) { if(!id || !coord.get(id)) deny('MISSING_TASK','Delegated task is not active.'); coord.attach(id,agent,session); }
  }
  coord.audit('hook',{agent,session,event,tool,toolId,task:id,project:root});
  if (event==='SessionStart') {
    if (!ag && agent==='claude' && process.env.CLAUDE_ENV_FILE) appendFileSync(process.env.CLAUDE_ENV_FILE,`\nexport AGENT_COLLAB_NATIVE_SESSION_ID='${session}'\nexport AGENT_COLLAB_NATIVE_AGENT='claude'\n`);
    const note=`[agent-collab] agent=${agent} session=${session} project=${root}. Delegation is explicit only. ${delegated?'Worker: do not delegate; keep assigned scope.':'Shared task coordination active.'}${ag?' Explicit delegation/conflicts: @@HOME@@/.agent-collab/PROTOCOL.md.':''}`;
    emit(ag?{injectSteps:[{systemMessage:{systemMessage:note}}]}:{hookSpecificOutput:{hookEventName:event,additionalContext:note}});
  } else if (['Stop','SessionEnd','Interrupt'].includes(event)) {
    if (!delegated) coord.release(id);
    if (event==='SessionEnd') coord.endSession(agent,session);
    emit(ag?{decision:'stop'}:{});
  } else if (['PostToolUse','PostToolUseFailure','PermissionDenied'].includes(event)) {
    if (typeof toolId==='string') coord.unclaim(id,toolId);
    emit({});
  } else if (event==='PostToolBatch') {
    for (const call of input.tool_calls??[]) if(typeof call.tool_use_id==='string') coord.unclaim(id,call.tool_use_id);
    emit({});
  } else if(event==='PreToolUse') {
    if (readTools.has(tool)) { if(ag) emit({decision:'allow'}); process.exit(0); }
    if (delegated && delegateTools.has(tool)) deny('NESTED_DELEGATION','Workers cannot delegate.');
    const targets=[];
    for (const p of [args.file_path,args.filePath,args.notebook_path,args.path,args.Path,args.TargetFile,...(Array.isArray(args.paths)?args.paths:[])]) if(typeof p==='string') targets.push(p);
    for(const v of Object.values(args)) if(typeof v==='string') for(const m of v.matchAll(/^\*\*\* (?:Add File|Update File|Delete File|Move to): (.+?)\s*$/gm)) targets.push(m[1]);
    const command=shellTools.has(tool)?String(args.command??args.cmd??args.CommandLine??''):null;
    if(command!==null){
      const verdict=classifyShell(command,{isSelfScript:p=>canonical(path.resolve(cwd,p))===canonical(fileURLToPath(new URL('./delegate.mjs',import.meta.url)))});
      const segments=splitShell(command);
      const exactBridge=segments.length===1 && !/[;|&$`{}()<>\r\n]|\\[\"']/.test(command) && !segments[0].redirect && !segments[0].dynamic && /^(?:node|node.exe)$/i.test(segments[0].argv[0]??'') && canonical(path.resolve(cwd,segments[0].argv[1]??''))===canonical(fileURLToPath(new URL('./delegate.mjs',import.meta.url)));
      if(verdict==='self' && exactBridge && !delegated) { if(ag) emit({decision:'allow'}); process.exit(0); }
      if(delegated && verdict==='self') deny('NESTED_DELEGATION','Workers cannot invoke the bridge.');
      // Only a bounded literal read grammar bypasses reservations; the legacy classifier is not a shell sandbox.
      const literalRead=/^(?:pwd|Get-Location|git (?:status(?: --short| --porcelain)?|branch --show-current|rev-parse --show-toplevel)|Get-Content -LiteralPath (?:'[^'\r\n]+'|[A-Za-z0-9_.:\\/\\-]+)(?: -Raw)?|cat -- '[^'\r\n]+')$/i.test(command.trim());
      if(literalRead) { if(ag) emit({decision:'allow'}); process.exit(0); }
      if(verdict==='deny' && delegated) deny('GIT_MUTATION','Git mutation requires an explicit user-managed action.');
      if(delegated && verdict==='delegate') deny('NESTED_DELEGATION','Workers cannot invoke another agent.');
    }
    if(delegated && command===null && targets.length===0) deny('UNCLASSIFIED_WORKER_TOOL','Worker tool has no verified read-only contract or file scope.');
    const writing=command!==null||targets.length>0;
    if(writing){
      if(delegated && process.env.AGENT_COLLAB_MODE==='read') deny('READ_ONLY_WORKER','Read-only task cannot write.');
      if(typeof session!=='string'||typeof toolId!=='string'||!toolId||toolId.endsWith(':undefined')) deny('MISSING_ID','Native session and tool IDs are required for writes.');
      const paths=targets.map(p=>canonical(path.resolve(cwd,p)));
      if(paths.some(p=>/(?:^|\/)\.git(?:\/|$)/.test(p))) deny('PROTECTED_PATH','Do not edit Git metadata.');
      if(delegated && paths.some(p=>/(?:^|\/)(?:\.agents|\.claude|\.codex|\.gemini|\.agent-collab)(?:\/|$)/.test(p))) deny('PROTECTED_PATH','Workers cannot modify agent configuration.');
      // Unknown shells can escape cwd: reserve all global writes until their completion callback.
      coord.claim(id,meta,root,command!==null?['.']:paths,command!==null?toolId:null,command!==null);
    }
    if(ag) emit({decision:'allow'});
  } else emit({});
} catch(error) { if(event==='PreToolUse') deny(error.code??'INTERNAL',error.message); else {process.stderr.write(error.message);process.exitCode=2;} }
