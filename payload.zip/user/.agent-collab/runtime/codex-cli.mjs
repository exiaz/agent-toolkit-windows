// Native Codex stdio launcher for TasteCode custom-harnesses; no protocol or permission overrides.
import {spawn} from 'node:child_process';
import path from 'node:path';
const env={...process.env};
for(const key of ['CODEX_APP_RUNTIME_CLI_PATH','CODEX_APP_TOOLS_PIPE_PATH','CODEX_INTERNAL_ORIGINATOR_OVERRIDE','CODEX_TOOL_CALL_ID','CODEX_WINDOWS_REGISTERED_CORE','CODEX_WINDOWS_SANDBOX_PACKAGE_FAMILY','CODEX_TASK_WORKSPACE_VERIFYING_IDENTITY','CODEX_THREAD_ID','CODEX_SESSION_ID'])delete env[key];
const cli=path.join(env.APPDATA,'npm/node_modules/@openai/codex/bin/codex.js');
const child=spawn(process.execPath,[cli,...process.argv.slice(2)],{env,stdio:'inherit',windowsHide:true});
child.on('error',error=>{process.stderr.write(error.message+'\n');process.exitCode=1;});
child.on('exit',(code)=>{process.exitCode=code??1;});
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>child.kill(signal));
