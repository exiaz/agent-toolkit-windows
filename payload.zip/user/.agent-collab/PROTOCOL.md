# Protokol kolaborasi agent

Runtime berada di `@@HOME@@/.agent-collab/runtime`. Aktifkan dan tinjau hooks melalui mekanisme native. Startup tidak meluncurkan worker.

## Delegasi eksplisit

Gunakan hanya atas permintaan pengguna:

```powershell
node "@@HOME@@/.agent-collab/runtime/delegate.mjs" --to claude --mode read --prompt-file C:/Tasks/task.txt --cwd C:/Projects/example
```

Gunakan `--to codex` untuk arah sebaliknya. Worker tidak boleh mendelegasikan lagi. Mode write memerlukan penugasan eksplisit dan `--scope` berisi berkas yang diizinkan. Permission dan sandbox native tetap berlaku. Pada proyek dengan koordinator lokal, gunakan workflow delegasi proyek tersebut.

## Scope dan konflik

Koordinasi memakai scope file absolut, identitas sesi native, transaksi mutex, serta hubungan parent/child. Worker read tidak boleh menulis. Scope write yang bertumpang tindih ditolak. Pertahankan branch dan perubahan lokal pengguna.

State tugas tersimpan lokal dan tidak dibagikan melalui paket. Jangan menyunting atau menghapus state secara manual, mengambil alih PID hidup, atau memaksa pelepasan klaim. Cleanup crash mengikuti lease dan pemeriksaan proses. Koordinasi hooks tidak menggantikan OS file lock dan tidak mencakup penyuntingan manual atau tools yang melewati hooks.

## Pemulihan

Backup worker write disimpan bersama laporan tugas. Jalankan `restore.mjs TASK_ID` setelah meninjau backup; pemulihan memvalidasi hash dan menolak perubahan baru atau konflik. Instalasi konfigurasi memiliki receipt dan backup terpisah yang dijelaskan di README toolkit.

## Harness

TasteCode menggunakan provider, sesi, dan kontrol izin native. Antigravity memakai schema hooks tersendiri dan payload camelCase; jangan menyamakan kontraknya dengan Codex atau Claude Code. Paket tidak mengaktifkan inbound delegation Antigravity. Tidak ada perubahan trust hash atau bypass permission otomatis.
